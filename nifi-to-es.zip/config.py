'''
Created on Oct 12, 2015

@author: mentzera
'''

es_host = '52.63.221.207'
es_port = 9200
es_bulk_chunk_size = 1000  #number of documents to index in a single bulk operation

